import type { FormErrors, Registration } from '@/types';
import { isDuplicateEmailEvent } from '@/utils/storage';

export function validateForm(
  data: Partial<Registration>,
  excludeId?: string
): FormErrors {
  const errors: FormErrors = {};

  if (!data.fullName || data.fullName.trim().length < 2) {
    errors.fullName = 'Full name is required (min 2 characters).';
  }

  if (!data.email || data.email.trim() === '') {
    errors.email = 'Email address is required.';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address.';
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.phone = 'Phone number is required.';
  } else if (!/^[+]?[0-9\s\-()]{10,15}$/.test(data.phone.trim()) || (data.phone.trim().replace(/\D/g, '').length < 10)) {
    errors.phone = 'Enter a valid phone number (at least 10 digits).';
  }

  if (!data.college || data.college.trim().length < 2) {
    errors.college = 'College name is required.';
  }

  if (!data.department || data.department.trim().length < 2) {
    errors.department = 'Department / course is required.';
  }

  if (!data.studentId || data.studentId.trim().length < 3) {
    errors.studentId = 'Student ID / register number is required.';
  }

  if (!data.eventId || data.eventId.trim() === '') {
    errors.eventId = 'Please select an event.';
  }

  if (!data.eventDate || data.eventDate.trim() === '') {
    errors.eventDate = 'Event date is required.';
  }

  if (
    data.email &&
    data.eventId &&
    !errors.email &&
    !errors.eventId &&
    isDuplicateEmailEvent(data.email, data.eventId, excludeId)
  ) {
    errors.email = 'You have already registered for this event with this email.';
  }

  return errors;
}

export function hasErrors(errors: FormErrors): boolean {
  return Object.keys(errors).length > 0;
}
