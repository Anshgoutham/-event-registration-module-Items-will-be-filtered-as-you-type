import type { Registration } from '@/types';

const STORAGE_KEY = 'event_registrations';

export function getRegistrations(): Registration[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveRegistrations(registrations: Registration[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(registrations));
}

export function addRegistration(registration: Registration): Registration[] {
  const all = getRegistrations();
  all.push(registration);
  saveRegistrations(all);
  return all;
}

export function updateRegistrationStatus(id: string, status: Registration['status']): Registration[] {
  const all = getRegistrations().map((r) =>
    r.id === id ? { ...r, status } : r
  );
  saveRegistrations(all);
  return all;
}

export function isDuplicateEmailEvent(email: string, eventId: string, excludeId?: string): boolean {
  return getRegistrations().some(
    (r) =>
      r.email.toLowerCase() === email.toLowerCase() &&
      r.eventId === eventId &&
      r.status !== 'Cancelled' &&
      r.id !== excludeId
  );
}

export function generateRegistrationId(): string {
  const year = new Date().getFullYear();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  const time = Date.now().toString().slice(-4);
  return `REG-${year}-${time}${random}`;
}
