import { useEffect } from 'react';
import { CheckCircle2, XCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  type: ToastType;
  message: string;
  onClose: () => void;
}

const TOAST_CONFIG: Record<ToastType, { icon: typeof CheckCircle2; bg: string; text: string; border: string }> = {
  success: { icon: CheckCircle2, bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200' },
  error: { icon: XCircle, bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-200' },
  info: { icon: Info, bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-200' },
};

export default function Toast({ type, message, onClose }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const config = TOAST_CONFIG[type];
  const Icon = config.icon;

  return (
    <div className="fixed bottom-6 right-6 z-[200] animate-[slideUp_0.3s_ease-out]">
      <div className={`flex items-center gap-3 ${config.bg} ${config.border} ${config.text} border rounded-xl shadow-lg px-4 py-3 max-w-sm`}>
        <Icon className="w-5 h-5 shrink-0" />
        <span className="text-sm font-medium flex-1">{message}</span>
        <button onClick={onClose} className="shrink-0 opacity-60 hover:opacity-100 transition-opacity">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
