import { Calendar, MapPin, Tag } from 'lucide-react';
import type { EventItem } from '@/types';

interface EventCardProps {
  event: EventItem;
  onSelect?: (event: EventItem) => void;
  selected?: boolean;
  compact?: boolean;
}

const CATEGORY_COLORS: Record<EventItem['category'], string> = {
  Technical: 'bg-blue-100 text-blue-700 border-blue-200',
  Cultural: 'bg-rose-100 text-rose-700 border-rose-200',
  Workshop: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

export default function EventCard({ event, onSelect, selected, compact }: EventCardProps) {
  const formattedDate = new Date(event.date).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <button
      onClick={() => onSelect?.(event)}
      disabled={!onSelect}
      className={`text-left w-full rounded-2xl border-2 p-5 transition-all duration-200 ${
        selected
          ? 'border-blue-500 bg-blue-50 shadow-md scale-[1.02]'
          : 'border-gray-100 bg-white hover:border-blue-300 hover:shadow-md'
      } ${!onSelect ? 'cursor-default' : 'cursor-pointer'}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="font-semibold text-gray-800 text-base leading-snug">{event.name}</h3>
        <span className={`shrink-0 text-xs font-medium px-2.5 py-1 rounded-full border ${CATEGORY_COLORS[event.category]}`}>
          {event.category}
        </span>
      </div>
      {!compact && <p className="text-sm text-gray-500 mb-4 leading-relaxed">{event.description}</p>}
      <div className="flex flex-col gap-2 text-xs text-gray-500">
        <span className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-blue-500" />
          {formattedDate}
        </span>
        <span className="flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-blue-500" />
          {event.venue}
        </span>
        {compact && (
          <span className="flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5 text-blue-500" />
            {event.category}
          </span>
        )}
      </div>
    </button>
  );
}
