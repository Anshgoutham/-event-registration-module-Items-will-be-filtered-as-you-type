import { useState, useEffect, useCallback } from 'react';
import type { EventItem, Page, Registration } from '@/types';
import { SAMPLE_EVENTS } from '@/data/sampleEvents';
import {
  getRegistrations,
  updateRegistrationStatus,
} from '@/utils/storage';
import Navbar from '@/components/Navbar';
import Toast, { type ToastType } from '@/components/Toast';
import Dashboard from '@/pages/Dashboard';
import RegisterPage from '@/pages/RegisterPage';
import ConfirmationPage from '@/pages/ConfirmationPage';
import MyEventsPage from '@/pages/MyEventsPage';

type View =
  | { page: 'home' }
  | { page: 'register'; preselectedEventId?: string }
  | { page: 'confirmation'; registration: Registration }
  | { page: 'events' };

export default function App() {
  const [view, setView] = useState<View>({ page: 'home' });
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [toast, setToast] = useState<{ type: ToastType; message: string } | null>(null);
  const [preselectedEvent, setPreselectedEvent] = useState<string | undefined>(undefined);

  useEffect(() => {
    setRegistrations(getRegistrations());
  }, []);

  const showToast = useCallback((type: ToastType, message: string) => {
    setToast({ type, message });
  }, []);

  const handleNavigate = useCallback((page: Page) => {
    if (page === 'home') setView({ page: 'home' });
    else if (page === 'register') {
      setPreselectedEvent(undefined);
      setView({ page: 'register' });
    } else if (page === 'events') setView({ page: 'events' });
  }, []);

  const handleSelectEvent = useCallback((event: EventItem) => {
    setPreselectedEvent(event.id);
    setView({ page: 'register', preselectedEventId: event.id });
  }, []);

  const handleRegistered = useCallback((registration: Registration) => {
    setRegistrations(getRegistrations());
    setView({ page: 'confirmation', registration });
  }, []);

  const handleCancel = useCallback((id: string) => {
    updateRegistrationStatus(id, 'Cancelled');
    setRegistrations(getRegistrations());
    showToast('info', 'Registration cancelled successfully.');
  }, [showToast]);

  const currentPage: Page =
    view.page === 'confirmation' ? 'events' : view.page;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50/50 via-gray-50 to-gray-50">
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />

      <main className="pb-12">
        {view.page === 'home' && (
          <Dashboard
            events={SAMPLE_EVENTS}
            registrations={registrations}
            onNavigate={handleNavigate}
            onSelectEvent={handleSelectEvent}
          />
        )}

        {view.page === 'register' && (
          <RegisterPage
            preselectedEventId={preselectedEvent}
            onRegistered={handleRegistered}
          />
        )}

        {view.page === 'confirmation' && (
          <ConfirmationPage
            registration={view.registration}
            onNavigate={handleNavigate}
          />
        )}

        {view.page === 'events' && (
          <MyEventsPage
            registrations={registrations}
            onCancel={handleCancel}
            onNavigate={handleNavigate}
          />
        )}
      </main>

      <footer className="border-t border-gray-100 bg-white/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 text-center">
          <p className="text-xs text-gray-400">
            Event Registration Module — College Assignment Project
          </p>
        </div>
      </footer>

      {toast && (
        <Toast
          type={toast.type}
          message={toast.message}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
