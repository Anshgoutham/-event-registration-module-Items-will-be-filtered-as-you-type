export type Gender = 'Male' | 'Female' | 'Other' | 'Prefer not to say';

export type RegistrationStatus = 'Confirmed' | 'Pending' | 'Cancelled';

export interface EventItem {
  id: string;
  name: string;
  date: string;
  description: string;
  venue: string;
  category: 'Technical' | 'Cultural' | 'Workshop';
}

export interface Registration {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  college: string;
  department: string;
  studentId: string;
  eventId: string;
  eventName: string;
  eventDate: string;
  gender?: Gender;
  comments?: string;
  status: RegistrationStatus;
  registrationDate: string;
}

export type Page = 'home' | 'register' | 'events';

export interface FormErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  college?: string;
  department?: string;
  studentId?: string;
  eventId?: string;
  eventDate?: string;
}
