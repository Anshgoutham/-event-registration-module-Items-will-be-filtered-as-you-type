import { Users, CalendarCheck, Clock, ArrowRight, TrendingUp, Sparkles } from 'lucide-react';
import type { EventItem, Registration, Page } from '@/types';
import EventCard from '@/components/EventCard';

interface DashboardProps {
  events: EventItem[];
  registrations: Registration[];
  onNavigate: (page: Page) => void;
  onSelectEvent: (event: EventItem) => void;
}

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export default function Dashboard({ events, registrations, onNavigate, onSelectEvent }: DashboardProps) {
  const activeRegs = registrations.filter((r) => r.status !== 'Cancelled');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const upcomingEvents = events
    .filter((e) => new Date(e.date) >= today)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const stats = [
    {
      label: 'Total Registrations',
      value: activeRegs.length,
      icon: Users,
      color: 'from-blue-500 to-blue-700',
      bg: 'bg-blue-50',
      iconColor: 'text-blue-600',
    },
    {
      label: 'Available Events',
      value: events.length,
      icon: CalendarCheck,
      color: 'from-emerald-500 to-emerald-700',
      bg: 'bg-emerald-50',
      iconColor: 'text-emerald-600',
    },
    {
      label: 'Upcoming Events',
      value: upcomingEvents.length,
      icon: Clock,
      color: 'from-amber-500 to-orange-600',
      bg: 'bg-amber-50',
      iconColor: 'text-amber-600',
    },
    {
      label: 'Confirmed',
      value: activeRegs.filter((r) => r.status === 'Confirmed').length,
      icon: TrendingUp,
      color: 'from-violet-500 to-violet-700',
      bg: 'bg-violet-50',
      iconColor: 'text-violet-600',
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 p-8 sm:p-12 mb-8 shadow-xl">
        <div className="absolute top-0 right-0 w-72 h-72 bg-white/10 rounded-full -translate-y-1/3 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/3 -translate-x-1/4" />
        <div className="relative">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-white text-xs font-medium mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            College Event Management System
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 leading-tight">
            Register for Events.<br />Showcase Your Talent.
          </h1>
          <p className="text-blue-100 text-sm sm:text-base max-w-lg mb-6 leading-relaxed">
            Browse upcoming college events, register with a single form, and track all your registrations in one place.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('register')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white text-blue-700 font-semibold text-sm rounded-xl hover:bg-blue-50 transition-colors shadow-md"
            >
              Register Now
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('events')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/10 text-white font-semibold text-sm rounded-xl hover:bg-white/20 transition-colors border border-white/20"
            >
              View My Events
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div className={`w-11 h-11 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${stat.iconColor}`} />
              </div>
              <p className="text-2xl sm:text-3xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Upcoming Events */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Upcoming Events</h2>
            <p className="text-sm text-gray-500 mt-0.5">Click an event to start registration</p>
          </div>
          <button
            onClick={() => onNavigate('register')}
            className="text-sm font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            All Events
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {upcomingEvents.map((event) => (
            <EventCard key={event.id} event={event} onSelect={onSelectEvent} />
          ))}
        </div>
      </div>

      {/* Recent Registrations */}
      {activeRegs.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-xl font-bold text-gray-800">Recent Registrations</h2>
            <button
              onClick={() => onNavigate('events')}
              className="text-sm font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              View All
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {activeRegs
              .slice()
              .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime())
              .slice(0, 4)
              .map((reg, i) => (
                <div
                  key={reg.id}
                  className={`flex items-center justify-between p-4 ${
                    i !== Math.min(3, activeRegs.length - 1) ? 'border-b border-gray-50' : ''
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                      <span className="text-sm font-bold text-blue-700">
                        {reg.fullName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{reg.fullName}</p>
                      <p className="text-xs text-gray-500 truncate">{reg.eventName}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-2">
                    <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded-full ${
                      reg.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-700' :
                      reg.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                      'bg-gray-100 text-gray-500'
                    }`}>
                      {reg.status}
                    </span>
                    <p className="text-xs text-gray-400 mt-0.5">{formatDate(reg.eventDate)}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
