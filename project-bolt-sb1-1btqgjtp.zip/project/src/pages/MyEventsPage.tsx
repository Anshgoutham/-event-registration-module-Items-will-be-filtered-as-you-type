import { useState, useMemo } from 'react';
import {
  Search, Filter, ListChecks, Eye, XCircle, X, Calendar, Mail, Phone, School,
  BookOpen, Hash, CalendarDays, CheckCircle2, Clock, Inbox,
} from 'lucide-react';
import type { Registration, RegistrationStatus, Page } from '@/types';
import ConfirmDialog from '@/components/ConfirmDialog';

interface MyEventsPageProps {
  registrations: Registration[];
  onCancel: (id: string) => void;
  onNavigate: (page: Page) => void;
}

const STATUS_OPTIONS: ('All' | RegistrationStatus)[] = ['All', 'Confirmed', 'Pending', 'Cancelled'];

const STATUS_BADGE: Record<RegistrationStatus, string> = {
  Confirmed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  Pending: 'bg-amber-100 text-amber-700 border-amber-200',
  Cancelled: 'bg-gray-100 text-gray-500 border-gray-200',
};

const STATUS_ICON: Record<RegistrationStatus, typeof CheckCircle2> = {
  Confirmed: CheckCircle2,
  Pending: Clock,
  Cancelled: XCircle,
};

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function formatDateTime(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

export default function MyEventsPage({ registrations, onCancel, onNavigate }: MyEventsPageProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | RegistrationStatus>('All');
  const [viewing, setViewing] = useState<Registration | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Registration | null>(null);

  const filtered = useMemo(() => {
    return registrations
      .filter((r) => {
        if (statusFilter !== 'All' && r.status !== statusFilter) return false;
        if (search.trim()) {
          const q = search.trim().toLowerCase();
          return (
            r.eventName.toLowerCase().includes(q) ||
            r.fullName.toLowerCase().includes(q) ||
            r.id.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime());
  }, [registrations, search, statusFilter]);

  const handleConfirmCancel = () => {
    if (cancelTarget) {
      onCancel(cancelTarget.id);
      setCancelTarget(null);
    }
  };

  const viewDetails = [
    { icon: Hash, label: 'Registration ID', value: viewing?.id },
    { icon: Hash, label: 'Student ID', value: viewing?.studentId },
    { icon: Mail, label: 'Email', value: viewing?.email },
    { icon: Phone, label: 'Phone', value: viewing?.phone },
    { icon: School, label: 'College', value: viewing?.college },
    { icon: BookOpen, label: 'Department', value: viewing?.department },
    { icon: Calendar, label: 'Event Date', value: viewing ? formatDate(viewing.eventDate) : '' },
    { icon: CalendarDays, label: 'Registered On', value: viewing ? formatDateTime(viewing.registrationDate) : '' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
          <ListChecks className="w-5 h-5 text-blue-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">My Events</h1>
          <p className="text-sm text-gray-500">View and manage your event registrations</p>
        </div>
      </div>

      {/* Controls */}
      {registrations.length > 0 && (
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by event name, participant name, or registration ID..."
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 text-sm text-gray-800 bg-white outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400 shrink-0" />
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
              {STATUS_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setStatusFilter(opt)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                    statusFilter === opt
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {registrations.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
            <Inbox className="w-10 h-10 text-gray-300" />
          </div>
          <h3 className="text-lg font-semibold text-gray-700 mb-1">No Registrations Yet</h3>
          <p className="text-sm text-gray-400 max-w-sm mb-6">
            You haven't registered for any events. Browse our events and register to see them here.
          </p>
          <button
            onClick={() => onNavigate('register')}
            className="px-5 py-2.5 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition-colors shadow-md"
          >
            Register for an Event
          </button>
        </div>
      )}

      {/* No Filter Results */}
      {registrations.length > 0 && filtered.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-3">
            <Search className="w-8 h-8 text-gray-300" />
          </div>
          <h3 className="text-base font-semibold text-gray-700 mb-1">No Matching Results</h3>
          <p className="text-sm text-gray-400">Try a different search term or filter</p>
        </div>
      )}

      {/* Registration Cards */}
      {filtered.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((reg) => {
            const StatusIcon = STATUS_ICON[reg.status];
            return (
              <div
                key={reg.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow p-5 flex flex-col"
              >
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-gray-800 text-sm truncate">{reg.eventName}</h3>
                    <p className="text-xs text-gray-400 mt-0.5">{reg.id}</p>
                  </div>
                  <span className={`shrink-0 inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full border ${STATUS_BADGE[reg.status]}`}>
                    <StatusIcon className="w-3 h-3" />
                    {reg.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-gray-500 mb-4 flex-1">
                  <p className="flex items-center gap-1.5">
                    <Hash className="w-3.5 h-3.5 text-gray-400" />
                    {reg.fullName}
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    Event: {formatDate(reg.eventDate)}
                  </p>
                  <p className="flex items-center gap-1.5">
                    <CalendarDays className="w-3.5 h-3.5 text-gray-400" />
                    Registered: {formatDate(reg.registrationDate)}
                  </p>
                </div>

                <div className="flex gap-2 pt-3 border-t border-gray-50">
                  <button
                    onClick={() => setViewing(reg)}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 text-gray-600 font-medium text-xs hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Details
                  </button>
                  {reg.status !== 'Cancelled' && (
                    <button
                      onClick={() => setCancelTarget(reg)}
                      className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 text-red-500 font-medium text-xs hover:bg-red-50 hover:border-red-200 transition-all"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Detail Modal */}
      {viewing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm animate-[fadeIn_0.15s_ease-in]" onClick={() => setViewing(null)} />
          <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto animate-[scaleIn_0.2s_ease-out]">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Registration Details</h3>
                <p className="text-xs text-gray-400">{viewing.id}</p>
              </div>
              <button
                onClick={() => setViewing(null)}
                className="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-3 mb-5 p-4 rounded-xl bg-blue-50">
                <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">{viewing.fullName.charAt(0).toUpperCase()}</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{viewing.fullName}</p>
                  <p className="text-sm text-gray-500">{viewing.eventName}</p>
                </div>
                <span className={`ml-auto inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full border ${STATUS_BADGE[viewing.status]}`}>
                  {viewing.status}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {viewDetails.map((detail) => {
                  const Icon = detail.icon;
                  return (
                    <div key={detail.label} className="flex items-start gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center shrink-0">
                        <Icon className="w-3.5 h-3.5 text-gray-400" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs text-gray-400">{detail.label}</p>
                        <p className="text-sm text-gray-700 font-medium break-words">{detail.value}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {viewing.gender && (
                <div className="mt-4 pt-4 border-t border-gray-50">
                  <p className="text-xs text-gray-400">Gender</p>
                  <p className="text-sm text-gray-700 font-medium">{viewing.gender}</p>
                </div>
              )}
              {viewing.comments && (
                <div className="mt-4 pt-4 border-t border-gray-50">
                  <p className="text-xs text-gray-400">Additional Comments</p>
                  <p className="text-sm text-gray-700 mt-1 leading-relaxed">{viewing.comments}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Cancel Dialog */}
      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel Registration?"
        message={`Are you sure you want to cancel your registration for "${cancelTarget?.eventName}"? This action cannot be undone.`}
        confirmLabel="Yes, Cancel"
        cancelLabel="Keep Registration"
        onConfirm={handleConfirmCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
}
