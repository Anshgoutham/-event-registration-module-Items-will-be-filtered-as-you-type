import { useState, useEffect } from 'react';
import { ClipboardList, RotateCcw, Send, User, Mail, Phone, School, BookOpen, Hash, Calendar, MessageSquare } from 'lucide-react';
import type { EventItem, FormErrors, Gender, Registration } from '@/types';
import { SAMPLE_EVENTS } from '@/data/sampleEvents';
import { validateForm, hasErrors } from '@/utils/validation';
import { addRegistration, generateRegistrationId } from '@/utils/storage';
import FormField from '@/components/FormField';
import EventCard from '@/components/EventCard';

interface RegisterPageProps {
  preselectedEventId?: string;
  onRegistered: (registration: Registration) => void;
}

const GENDER_OPTIONS: Gender[] = ['Male', 'Female', 'Other', 'Prefer not to say'];

export default function RegisterPage({ preselectedEventId, onRegistered }: RegisterPageProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [college, setCollege] = useState('');
  const [department, setDepartment] = useState('');
  const [studentId, setStudentId] = useState('');
  const [eventId, setEventId] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [gender, setGender] = useState('');
  const [comments, setComments] = useState('');
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (preselectedEventId) {
      setEventId(preselectedEventId);
      const event = SAMPLE_EVENTS.find((e) => e.id === preselectedEventId);
      if (event) setEventDate(event.date);
    }
  }, [preselectedEventId]);

  const selectedEvent = SAMPLE_EVENTS.find((e) => e.id === eventId);

  const handleEventSelect = (event: EventItem) => {
    setEventId(event.id);
    setEventDate(event.date);
    setErrors((prev) => ({ ...prev, eventId: undefined, eventDate: undefined }));
  };

  const handleReset = () => {
    setFullName('');
    setEmail('');
    setPhone('');
    setCollege('');
    setDepartment('');
    setStudentId('');
    setEventId('');
    setEventDate('');
    setGender('');
    setComments('');
    setErrors({});
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const formData: Partial<Registration> = {
      fullName,
      email,
      phone,
      college,
      department,
      studentId,
      eventId,
      eventDate,
    };

    const formErrors = validateForm(formData);
    setErrors(formErrors);

    if (hasErrors(formErrors)) {
      setSubmitting(false);
      return;
    }

    const registration: Registration = {
      id: generateRegistrationId(),
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      college: college.trim(),
      department: department.trim(),
      studentId: studentId.trim(),
      eventId,
      eventName: selectedEvent?.name ?? '',
      eventDate,
      gender: (gender || undefined) as Gender | undefined,
      comments: comments.trim() || undefined,
      status: 'Confirmed',
      registrationDate: new Date().toISOString(),
    };

    addRegistration(registration);
    setSubmitting(false);
    onRegistered(registration);
  };

  const inputClass = (hasError?: string) =>
    `w-full pl-10 pr-3 py-2.5 rounded-lg border text-sm text-gray-800 bg-white outline-none transition-all ${
      hasError
        ? 'border-red-300 focus:border-red-500 focus:ring-2 focus:ring-red-100'
        : 'border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
    }`;

  const selectClass = (hasError?: string, isEmpty?: boolean) =>
    `w-full pl-3 pr-8 py-2.5 rounded-lg border text-sm bg-white outline-none transition-all cursor-pointer ${
      hasError
        ? 'border-red-300 focus:border-red-500 focus:ring-2 focus:ring-red-100'
        : 'border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100'
    } ${isEmpty ? 'text-gray-400' : 'text-gray-800'}`;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <ClipboardList className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Event Registration</h1>
            <p className="text-sm text-gray-500">Fill in your details to register for an event</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8">
            <h2 className="text-lg font-semibold text-gray-800 mb-1">Participant Details</h2>
            <p className="text-sm text-gray-400 mb-6">Fields marked with * are required</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Full Name */}
              <div className="sm:col-span-2">
                <FormField label="Full Name" required error={errors.fullName} htmlFor="fullName">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      id="fullName"
                      type="text"
                      value={fullName}
                      onChange={(e) => { setFullName(e.target.value); setErrors((p) => ({ ...p, fullName: undefined })); }}
                      placeholder="e.g. John Doe"
                      className={inputClass(errors.fullName)}
                    />
                  </div>
                </FormField>
              </div>

              {/* Email */}
              <FormField label="Email Address" required error={errors.email} htmlFor="email">
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setErrors((p) => ({ ...p, email: undefined })); }}
                    placeholder="e.g. john@college.edu"
                    className={inputClass(errors.email)}
                  />
                </div>
              </FormField>

              {/* Phone */}
              <FormField label="Phone Number" required error={errors.phone} htmlFor="phone">
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => { setPhone(e.target.value); setErrors((p) => ({ ...p, phone: undefined })); }}
                    placeholder="e.g. 9876543210"
                    className={inputClass(errors.phone)}
                  />
                </div>
              </FormField>

              {/* College */}
              <FormField label="College Name" required error={errors.college} htmlFor="college">
                <div className="relative">
                  <School className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="college"
                    type="text"
                    value={college}
                    onChange={(e) => { setCollege(e.target.value); setErrors((p) => ({ ...p, college: undefined })); }}
                    placeholder="e.g. National Institute of Technology"
                    className={inputClass(errors.college)}
                  />
                </div>
              </FormField>

              {/* Department */}
              <FormField label="Department / Course" required error={errors.department} htmlFor="department">
                <div className="relative">
                  <BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="department"
                    type="text"
                    value={department}
                    onChange={(e) => { setDepartment(e.target.value); setErrors((p) => ({ ...p, department: undefined })); }}
                    placeholder="e.g. Computer Science"
                    className={inputClass(errors.department)}
                  />
                </div>
              </FormField>

              {/* Student ID */}
              <FormField label="Student ID / Register Number" required error={errors.studentId} htmlFor="studentId">
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    id="studentId"
                    type="text"
                    value={studentId}
                    onChange={(e) => { setStudentId(e.target.value); setErrors((p) => ({ ...p, studentId: undefined })); }}
                    placeholder="e.g. CS21B001"
                    className={inputClass(errors.studentId)}
                  />
                </div>
              </FormField>

              {/* Event Select */}
              <FormField label="Select Event" required error={errors.eventId} htmlFor="eventId">
                <select
                  id="eventId"
                  value={eventId}
                  onChange={(e) => {
                    setEventId(e.target.value);
                    const evt = SAMPLE_EVENTS.find((ev) => ev.id === e.target.value);
                    if (evt) setEventDate(evt.date);
                    setErrors((p) => ({ ...p, eventId: undefined, eventDate: undefined }));
                  }}
                  className={selectClass(errors.eventId, eventId === '')}
                >
                  <option value="">-- Choose an event --</option>
                  {SAMPLE_EVENTS.map((event) => (
                    <option key={event.id} value={event.id}>
                      {event.name} — {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </option>
                  ))}
                </select>
              </FormField>

              {/* Event Date */}
              <FormField label="Event Date" required error={errors.eventDate} htmlFor="eventDate">
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                  <input
                    id="eventDate"
                    type="date"
                    value={eventDate}
                    onChange={(e) => { setEventDate(e.target.value); setErrors((p) => ({ ...p, eventDate: undefined })); }}
                    className={inputClass(errors.eventDate)}
                  />
                </div>
              </FormField>

              {/* Gender */}
              <FormField label="Gender (optional)" htmlFor="gender">
                <select
                  id="gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className={selectClass(undefined, gender === '')}
                >
                  <option value="">-- Select gender --</option>
                  {GENDER_OPTIONS.map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </FormField>

              {/* Comments */}
              <div className="sm:col-span-2">
                <FormField label="Additional Comments (optional)" htmlFor="comments">
                  <div className="relative">
                    <MessageSquare className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <textarea
                      id="comments"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      rows={3}
                      placeholder="Any dietary restrictions, accessibility needs, or questions..."
                      className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm text-gray-800 outline-none transition-all resize-none"
                    />
                  </div>
                </FormField>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex flex-col-reverse sm:flex-row gap-3 mt-8">
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg border border-gray-200 text-gray-600 font-medium text-sm hover:bg-gray-50 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                Reset Form
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition-colors shadow-md disabled:opacity-60"
              >
                <Send className="w-4 h-4" />
                {submitting ? 'Registering...' : 'Register Now'}
              </button>
            </div>
          </form>
        </div>

        {/* Event Selection Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-blue-600" />
              Choose Event
            </h3>
            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
              {SAMPLE_EVENTS.map((event) => (
                <EventCard
                  key={event.id}
                  event={event}
                  compact
                  selected={eventId === event.id}
                  onSelect={handleEventSelect}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
