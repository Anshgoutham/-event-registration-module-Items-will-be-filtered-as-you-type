import { CheckCircle2, Home, Download, Printer, Calendar, Mail, User, Hash, PartyPopper } from 'lucide-react';
import type { Registration, Page } from '@/types';

interface ConfirmationPageProps {
  registration: Registration;
  onNavigate: (page: Page) => void;
}

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}

function formatDateTime(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export default function ConfirmationPage({ registration, onNavigate }: ConfirmationPageProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const content = [
      'EVENT REGISTRATION CONFIRMATION',
      '================================',
      '',
      `Registration ID: ${registration.id}`,
      `Participant Name: ${registration.fullName}`,
      `Event Name: ${registration.eventName}`,
      `Event Date: ${formatDate(registration.eventDate)}`,
      `Email: ${registration.email}`,
      `Phone: ${registration.phone}`,
      `College: ${registration.college}`,
      `Department: ${registration.department}`,
      `Student ID: ${registration.studentId}`,
      `Status: ${registration.status}`,
      `Registered On: ${formatDateTime(registration.registrationDate)}`,
      registration.gender ? `Gender: ${registration.gender}` : '',
      registration.comments ? `Comments: ${registration.comments}` : '',
    ]
      .filter(Boolean)
      .join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `registration-${registration.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const details = [
    { icon: User, label: 'Participant Name', value: registration.fullName },
    { icon: Hash, label: 'Registration ID', value: registration.id },
    { icon: Calendar, label: 'Event', value: registration.eventName },
    { icon: Calendar, label: 'Event Date', value: formatDate(registration.eventDate) },
    { icon: Mail, label: 'Email', value: registration.email },
  ];

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      {/* Success Animation */}
      <div className="text-center mb-8">
        <div className="relative inline-flex">
          <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center animate-[scaleIn_0.4s_ease-out]">
            <CheckCircle2 className="w-12 h-12 text-emerald-600" />
          </div>
          <div className="absolute -top-2 -right-2">
            <PartyPopper className="w-6 h-6 text-amber-500 animate-[bounce_1s_ease-in-out_infinite]" />
          </div>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mt-4">Registration Successful!</h1>
        <p className="text-gray-500 mt-2">
          You have been registered for <span className="font-semibold text-blue-600">{registration.eventName}</span>
        </p>
      </div>

      {/* Confirmation Card */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden print:shadow-none print:border-0">
        {/* Card Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-5 print:bg-blue-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-xs font-medium uppercase tracking-wide">Registration Confirmation</p>
              <p className="text-white text-lg font-bold mt-0.5">{registration.eventName}</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-100 text-xs font-semibold border border-emerald-300/30">
              {registration.status}
            </span>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-6">
          <div className="space-y-4">
            {details.map((detail) => {
              const Icon = detail.icon;
              return (
                <div key={detail.label} className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-400 font-medium">{detail.label}</p>
                    <p className="text-sm text-gray-800 font-medium break-words">{detail.value}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-gray-100 mt-5 pt-4">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>Registered on {formatDateTime(registration.registrationDate)}</span>
              <span>{registration.college}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 mt-6 print:hidden">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg border border-gray-200 text-gray-600 font-medium text-sm hover:bg-gray-50 transition-colors"
        >
          <Home className="w-4 h-4" />
          Back to Home
        </button>
        <button
          onClick={handleDownload}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg border border-gray-200 text-gray-600 font-medium text-sm hover:bg-gray-50 transition-colors"
        >
          <Download className="w-4 h-4" />
          Download
        </button>
        <button
          onClick={handlePrint}
          className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition-colors shadow-md"
        >
          <Printer className="w-4 h-4" />
          Print Confirmation
        </button>
      </div>
    </div>
  );
}
