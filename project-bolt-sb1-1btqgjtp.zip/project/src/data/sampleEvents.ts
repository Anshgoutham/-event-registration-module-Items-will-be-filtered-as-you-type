import type { EventItem } from '@/types';

export const SAMPLE_EVENTS: EventItem[] = [
  {
    id: 'evt-001',
    name: 'Technical Quiz',
    date: '2026-10-20',
    description: 'Test your knowledge across programming, electronics, and general tech in this fast-paced quiz competition.',
    venue: 'Seminar Hall A',
    category: 'Technical',
  },
  {
    id: 'evt-002',
    name: 'Coding Competition',
    date: '2026-10-25',
    description: 'Solve algorithmic challenges under a time limit. Individual and team rounds with prizes for top performers.',
    venue: 'Computer Lab 3',
    category: 'Technical',
  },
  {
    id: 'evt-003',
    name: 'Web Development Workshop',
    date: '2026-11-02',
    description: 'Hands-on workshop covering modern React, Tailwind CSS, and building a complete project from scratch.',
    venue: 'Workshop Room B',
    category: 'Workshop',
  },
  {
    id: 'evt-004',
    name: 'Project Expo',
    date: '2026-11-10',
    description: 'Showcase your innovative projects to a panel of judges. Open to all departments and all year groups.',
    venue: 'Main Auditorium',
    category: 'Technical',
  },
  {
    id: 'evt-005',
    name: 'Cultural Fest',
    date: '2026-11-18',
    description: 'A celebration of music, dance, and art. Compete or perform in this year-long anticipated cultural extravaganza.',
    venue: 'Open Air Stage',
    category: 'Cultural',
  },
];
